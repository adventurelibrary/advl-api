--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.14
-- Dumped by pg_dump version 13.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE adventurelibrary;
--
-- Name: adventurelibrary; Type: DATABASE; Schema: -; Owner: advl
--

CREATE DATABASE adventurelibrary WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE adventurelibrary OWNER TO advl;

\connect adventurelibrary

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: category; Type: TYPE; Schema: public; Owner: advl
--

CREATE TYPE public.category AS ENUM (
    'map',
    'token',
    'character',
    'scene',
    'item',
    'panel'
);


ALTER TYPE public.category OWNER TO advl;

--
-- Name: filetype; Type: TYPE; Schema: public; Owner: advl
--

CREATE TYPE public.filetype AS ENUM (
    'IMAGE',
    'PDF',
    'ZIP'
);


ALTER TYPE public.filetype OWNER TO advl;

--
-- Name: visibility; Type: TYPE; Schema: public; Owner: advl
--

CREATE TYPE public.visibility AS ENUM (
    'PENDING',
    'HIDDEN',
    'PUBLIC',
    'ALL'
);


ALTER TYPE public.visibility OWNER TO advl;

--
-- Name: db_to_csv(text); Type: FUNCTION; Schema: public; Owner: advl
--

CREATE FUNCTION public.db_to_csv(path text) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
   tables RECORD;
   statement TEXT;
begin
FOR tables IN 
   SELECT (table_schema || '.' || table_name) AS schema_table
   FROM information_schema.tables t INNER JOIN information_schema.schemata s 
   ON s.schema_name = t.table_schema 
   WHERE t.table_schema NOT IN ('pg_catalog', 'information_schema', 'configuration')
   AND t.table_type NOT IN ('VIEW')
   ORDER BY schema_table
LOOP
   statement := 'COPY ' || tables.schema_table || ' TO ''' || path || '/' || tables.schema_table || '.csv' ||''' DELIMITER '';'' CSV HEADER';
   EXECUTE statement;
END LOOP;
return;  
end;
$$;


ALTER FUNCTION public.db_to_csv(path text) OWNER TO advl;

SET default_tablespace = '';

--
-- Name: assets; Type: TABLE; Schema: public; Owner: advl
--

CREATE TABLE public.assets (
    id text NOT NULL,
    slug text NOT NULL,
    size_in_bytes integer NOT NULL,
    uploaded timestamp without time zone NOT NULL,
    visibility public.visibility NOT NULL,
    unlock_count integer DEFAULT 0 NOT NULL,
    filetype public.filetype NOT NULL,
    original_file_ext text NOT NULL,
    creator_id text NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    category public.category DEFAULT 'map'::public.category NOT NULL,
    tags text[],
    unlock_price integer DEFAULT 0 NOT NULL,
    revenue_share json DEFAULT '{}'::jsonb
);


ALTER TABLE public.assets OWNER TO advl;

--
-- Name: bundleassets; Type: TABLE; Schema: public; Owner: advl
--

CREATE TABLE public.bundleassets (
    id text NOT NULL,
    asset_id text NOT NULL,
    time_added timestamp without time zone NOT NULL
);


ALTER TABLE public.bundleassets OWNER TO advl;

--
-- Name: bundleinfo; Type: TABLE; Schema: public; Owner: advl
--

CREATE TABLE public.bundleinfo (
    id text NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    public boolean NOT NULL,
    creator_id text,
    user_id text
);


ALTER TABLE public.bundleinfo OWNER TO advl;

--
-- Name: creatormembers; Type: TABLE; Schema: public; Owner: advl
--

CREATE TABLE public.creatormembers (
    creator_id text NOT NULL,
    user_id text NOT NULL
);


ALTER TABLE public.creatormembers OWNER TO advl;

--
-- Name: creators; Type: TABLE; Schema: public; Owner: advl
--

CREATE TABLE public.creators (
    id text NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    owner_id text,
    description text
);


ALTER TABLE public.creators OWNER TO advl;

--
-- Name: testing_table; Type: TABLE; Schema: public; Owner: advl
--

CREATE TABLE public.testing_table (
    id text
);


ALTER TABLE public.testing_table OWNER TO advl;

--
-- Name: users; Type: TABLE; Schema: public; Owner: advl
--

CREATE TABLE public.users (
    id text NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    notification_preferences json DEFAULT '{}'::jsonb,
    is_admin boolean DEFAULT false NOT NULL,
    last_seen timestamp without time zone NOT NULL,
    join_date timestamp without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO advl;

--
-- Data for Name: assets; Type: TABLE DATA; Schema: public; Owner: advl
--

COPY public.assets (id, slug, size_in_bytes, uploaded, visibility, unlock_count, filetype, original_file_ext, creator_id, name, description, category, tags, unlock_price, revenue_share) FROM stdin;
\.
COPY public.assets (id, slug, size_in_bytes, uploaded, visibility, unlock_count, filetype, original_file_ext, creator_id, name, description, category, tags, unlock_price, revenue_share) FROM '$$PATH$$/3858.dat';

--
-- Data for Name: bundleassets; Type: TABLE DATA; Schema: public; Owner: advl
--

COPY public.bundleassets (id, asset_id, time_added) FROM stdin;
\.
COPY public.bundleassets (id, asset_id, time_added) FROM '$$PATH$$/3861.dat';

--
-- Data for Name: bundleinfo; Type: TABLE DATA; Schema: public; Owner: advl
--

COPY public.bundleinfo (id, name, description, public, creator_id, user_id) FROM stdin;
\.
COPY public.bundleinfo (id, name, description, public, creator_id, user_id) FROM '$$PATH$$/3860.dat';

--
-- Data for Name: creatormembers; Type: TABLE DATA; Schema: public; Owner: advl
--

COPY public.creatormembers (creator_id, user_id) FROM stdin;
\.
COPY public.creatormembers (creator_id, user_id) FROM '$$PATH$$/3859.dat';

--
-- Data for Name: creators; Type: TABLE DATA; Schema: public; Owner: advl
--

COPY public.creators (id, slug, name, owner_id, description) FROM stdin;
\.
COPY public.creators (id, slug, name, owner_id, description) FROM '$$PATH$$/3857.dat';

--
-- Data for Name: testing_table; Type: TABLE DATA; Schema: public; Owner: advl
--

COPY public.testing_table (id) FROM stdin;
\.
COPY public.testing_table (id) FROM '$$PATH$$/3862.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: advl
--

COPY public.users (id, username, email, notification_preferences, is_admin, last_seen, join_date) FROM stdin;
\.
COPY public.users (id, username, email, notification_preferences, is_admin, last_seen, join_date) FROM '$$PATH$$/3856.dat';

--
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: public; Owner: advl
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (id);


--
-- Name: bundleinfo bundleinfo_pkey; Type: CONSTRAINT; Schema: public; Owner: advl
--

ALTER TABLE ONLY public.bundleinfo
    ADD CONSTRAINT bundleinfo_pkey PRIMARY KEY (id);


--
-- Name: creators creators_pkey; Type: CONSTRAINT; Schema: public; Owner: advl
--

ALTER TABLE ONLY public.creators
    ADD CONSTRAINT creators_pkey PRIMARY KEY (id);


--
-- Name: creators creators_slug_key; Type: CONSTRAINT; Schema: public; Owner: advl
--

ALTER TABLE ONLY public.creators
    ADD CONSTRAINT creators_slug_key UNIQUE (slug);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: advl
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: advl
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: advl
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: creators_slug; Type: INDEX; Schema: public; Owner: advl
--

CREATE UNIQUE INDEX creators_slug ON public.creators USING btree (slug);


--
-- Name: users_email; Type: INDEX; Schema: public; Owner: advl
--

CREATE UNIQUE INDEX users_email ON public.users USING btree (email);


--
-- Name: users_username; Type: INDEX; Schema: public; Owner: advl
--

CREATE UNIQUE INDEX users_username ON public.users USING btree (username);


--
-- Name: bundleassets fk_asset_id; Type: FK CONSTRAINT; Schema: public; Owner: advl
--

ALTER TABLE ONLY public.bundleassets
    ADD CONSTRAINT fk_asset_id FOREIGN KEY (asset_id) REFERENCES public.assets(id);


--
-- Name: bundleassets fk_bundle_id; Type: FK CONSTRAINT; Schema: public; Owner: advl
--

ALTER TABLE ONLY public.bundleassets
    ADD CONSTRAINT fk_bundle_id FOREIGN KEY (id) REFERENCES public.bundleinfo(id);


--
-- Name: assets fk_creator; Type: FK CONSTRAINT; Schema: public; Owner: advl
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT fk_creator FOREIGN KEY (creator_id) REFERENCES public.creators(id);


--
-- Name: creatormembers fk_creator; Type: FK CONSTRAINT; Schema: public; Owner: advl
--

ALTER TABLE ONLY public.creatormembers
    ADD CONSTRAINT fk_creator FOREIGN KEY (creator_id) REFERENCES public.creators(id);


--
-- Name: bundleinfo fk_creator_id; Type: FK CONSTRAINT; Schema: public; Owner: advl
--

ALTER TABLE ONLY public.bundleinfo
    ADD CONSTRAINT fk_creator_id FOREIGN KEY (creator_id) REFERENCES public.creators(id);


--
-- Name: creators fk_owner; Type: FK CONSTRAINT; Schema: public; Owner: advl
--

ALTER TABLE ONLY public.creators
    ADD CONSTRAINT fk_owner FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- Name: creatormembers fk_user; Type: FK CONSTRAINT; Schema: public; Owner: advl
--

ALTER TABLE ONLY public.creatormembers
    ADD CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: bundleinfo fk_user_id; Type: FK CONSTRAINT; Schema: public; Owner: advl
--

ALTER TABLE ONLY public.bundleinfo
    ADD CONSTRAINT fk_user_id FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: advl
--

REVOKE ALL ON SCHEMA public FROM rdsadmin;
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO advl;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

