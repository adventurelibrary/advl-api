--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.3
-- Dumped by pg_dump version 13.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE adventurelibrary;
--
-- Name: adventurelibrary; Type: DATABASE; Schema: -; Owner: advl
--

CREATE DATABASE adventurelibrary WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE adventurelibrary OWNER TO advl;

\connect adventurelibrary

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: category; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.category AS ENUM (
    'map',
    'token',
    'character',
    'scene',
    'item',
    'panel'
);


ALTER TYPE public.category OWNER TO postgres;

--
-- Name: entity_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.entity_type AS ENUM (
    'CREATOR',
    'USER',
    'ADMIN'
);


ALTER TYPE public.entity_type OWNER TO postgres;

--
-- Name: filetype; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.filetype AS ENUM (
    'IMAGE',
    'PDF',
    'ZIP'
);


ALTER TYPE public.filetype OWNER TO postgres;

--
-- Name: visibility; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.visibility AS ENUM (
    'PENDING',
    'HIDDEN',
    'PUBLIC',
    'ALL'
);


ALTER TYPE public.visibility OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: assets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.assets (
    id text NOT NULL,
    slug text NOT NULL,
    size_in_bytes integer NOT NULL,
    uploaded timestamp without time zone NOT NULL,
    visibility public.visibility NOT NULL,
    unlock_count integer DEFAULT 0 NOT NULL,
    filetype public.filetype NOT NULL,
    original_file_ext text NOT NULL,
    creator_id text NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    category public.category DEFAULT 'map'::public.category NOT NULL,
    tags text[],
    unlock_price integer DEFAULT 0 NOT NULL,
    revenue_share json DEFAULT '{}'::jsonb
);


ALTER TABLE public.assets OWNER TO postgres;

--
-- Name: bundleassets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bundleassets (
    id text NOT NULL,
    asset_id text NOT NULL,
    time_added timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.bundleassets OWNER TO postgres;

--
-- Name: bundleinfo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bundleinfo (
    id text NOT NULL,
    name text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    public boolean DEFAULT false NOT NULL,
    creator_id text NOT NULL
);


ALTER TABLE public.bundleinfo OWNER TO postgres;

--
-- Name: creatormembers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.creatormembers (
    creator_id text NOT NULL,
    user_id text NOT NULL
);


ALTER TABLE public.creatormembers OWNER TO postgres;

--
-- Name: creators; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.creators (
    id text NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    owner_id text NOT NULL,
    description text
);


ALTER TABLE public.creators OWNER TO postgres;

--
-- Name: entities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.entities (
    id text NOT NULL,
    type public.entity_type NOT NULL
);


ALTER TABLE public.entities OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id text NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    notification_preferences json DEFAULT '{}'::jsonb,
    last_seen timestamp without time zone NOT NULL,
    join_date timestamp without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: assets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.assets (id, slug, size_in_bytes, uploaded, visibility, unlock_count, filetype, original_file_ext, creator_id, name, description, category, tags, unlock_price, revenue_share) FROM stdin;
\.
COPY public.assets (id, slug, size_in_bytes, uploaded, visibility, unlock_count, filetype, original_file_ext, creator_id, name, description, category, tags, unlock_price, revenue_share) FROM '$$PATH$$/3061.dat';

--
-- Data for Name: bundleassets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bundleassets (id, asset_id, time_added) FROM stdin;
\.
COPY public.bundleassets (id, asset_id, time_added) FROM '$$PATH$$/3064.dat';

--
-- Data for Name: bundleinfo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bundleinfo (id, name, description, public, creator_id) FROM stdin;
\.
COPY public.bundleinfo (id, name, description, public, creator_id) FROM '$$PATH$$/3063.dat';

--
-- Data for Name: creatormembers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.creatormembers (creator_id, user_id) FROM stdin;
\.
COPY public.creatormembers (creator_id, user_id) FROM '$$PATH$$/3062.dat';

--
-- Data for Name: creators; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.creators (id, slug, name, owner_id, description) FROM stdin;
\.
COPY public.creators (id, slug, name, owner_id, description) FROM '$$PATH$$/3060.dat';

--
-- Data for Name: entities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.entities (id, type) FROM stdin;
\.
COPY public.entities (id, type) FROM '$$PATH$$/3058.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, email, notification_preferences, last_seen, join_date) FROM stdin;
\.
COPY public.users (id, username, email, notification_preferences, last_seen, join_date) FROM '$$PATH$$/3059.dat';

--
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (id);


--
-- Name: bundleinfo bundleinfo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bundleinfo
    ADD CONSTRAINT bundleinfo_pkey PRIMARY KEY (id);


--
-- Name: creators creators_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.creators
    ADD CONSTRAINT creators_pkey PRIMARY KEY (id);


--
-- Name: creators creators_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.creators
    ADD CONSTRAINT creators_slug_key UNIQUE (slug);


--
-- Name: entities entities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entities
    ADD CONSTRAINT entities_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: creatormembers_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX creatormembers_id ON public.creatormembers USING btree (creator_id, user_id);


--
-- Name: creators_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX creators_slug ON public.creators USING btree (slug);


--
-- Name: users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_email ON public.users USING btree (email);


--
-- Name: users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_username ON public.users USING btree (username);


--
-- Name: bundleassets fk_asset_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bundleassets
    ADD CONSTRAINT fk_asset_id FOREIGN KEY (asset_id) REFERENCES public.assets(id);


--
-- Name: bundleassets fk_bundle_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bundleassets
    ADD CONSTRAINT fk_bundle_id FOREIGN KEY (id) REFERENCES public.bundleinfo(id);


--
-- Name: assets fk_creator; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT fk_creator FOREIGN KEY (creator_id) REFERENCES public.creators(id);


--
-- Name: creatormembers fk_creator; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.creatormembers
    ADD CONSTRAINT fk_creator FOREIGN KEY (creator_id) REFERENCES public.creators(id);


--
-- Name: users fk_entity_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_entity_id FOREIGN KEY (id) REFERENCES public.entities(id);


--
-- Name: creators fk_entity_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.creators
    ADD CONSTRAINT fk_entity_id FOREIGN KEY (id) REFERENCES public.entities(id);


--
-- Name: bundleinfo fk_entity_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bundleinfo
    ADD CONSTRAINT fk_entity_id FOREIGN KEY (creator_id) REFERENCES public.entities(id);


--
-- Name: creators fk_owner; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.creators
    ADD CONSTRAINT fk_owner FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- Name: creatormembers fk_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.creatormembers
    ADD CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA public TO advl;


--
-- PostgreSQL database dump complete
--

